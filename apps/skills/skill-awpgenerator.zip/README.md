# AWP Generation Kit – run in M365 Copilot (GPT / Opus) or any model with a Python sandbox

Produces a complete Internal Audit Work Program (.xlsx) in the firm's 100/200/300-series template for **any** audit scope. Tested end-to-end in M365 Copilot Premium (GPT 5.6 and Opus 5): both execute Python, search the web, read attachments and return downloadable xlsx.

## Files
| File | What it is |
|---|---|
| `AWP_Master_Prompt.md` | The reusable prompt. Fill the INPUTS block, paste. |
| `awp_schema.json` | JSON schema the model must output. Attach with the prompt. |
| `build_awp.py` | Deterministic builder: JSON → formatted xlsx. Validates cross-references first. |
| `example_RMN_content.json` | Worked example (FairPrice Retail Media Network audit). |
| `example_StoreRenovation_content.json` | Worked example (FairPrice Store Renovation audit). |
| `example_Treasury_content.json` | Worked example (Treasury management audit – client-agnostic). |
| `AWP_Format_Spec.md` | Template conventions, for reviewers or re-implementing the builder in Office Script/VBA. |

## One-time setup
1. Unzip `AWP_Generation_Kit.zip` to a SharePoint/OneDrive folder (7 files).

## Workflow per audit (≈15 minutes)
1. Open M365 Copilot → **New chat** → select Opus 5 (or GPT 5.6). If the chat cannot run Python, use the **Analyst** agent instead.
2. Attach 4 files with the **+** button:
   - `awp_schema.json`
   - `build_awp.py`
   - ONE example JSON (e.g. `example_RMN_content.json`)
   - your SOW / scope document (txt, docx or pdf)
3. Open `AWP_Master_Prompt.md` in Notepad, fill the **INPUTS** block (client, audit name, period, area of focus or "NONE", output filename), copy the **whole file** into the chat and send.
4. Copilot researches, then returns a `<name>_content.json` download link plus a summary table (sub-processes, controls, tests, samples). Review it. Ask for changes in plain English ("add a test on X", "split sub-process 4", "sample 25 not 15"); Copilot regenerates the JSON.
5. Send the **BUILD COMMAND** (last section of `AWP_Master_Prompt.md`) as a new message, replacing `<name>`:
   > Run the attached `build_awp.py` on the attached `<name>_content.json` with Python. If it reports validation errors, fix the JSON and re-run. Then give me the download link for the .xlsx and print the build summary line.
6. Download the xlsx, open in Excel, confirm the Audit period on tab A, hand to the Senior Associate. Yellow cells = fieldwork input.

Troubleshooting
- Step 5 says it cannot find the JSON → reply: "Save the JSON you generated to a file first, then run the script on it."
- Validation errors printed → reply: "Fix the JSON so all control refs and test refs exist, then re-run."
- No web access in your tenant → paste research notes into OTHER CONTEXT in the prompt.
- First run recommendation: use the RMN SOW and compare against `FPG_RMN_Audit_Work_Program.xlsx` as the quality benchmark.

## Rules that keep quality stable
- Never ask the model to build the Excel directly from prose. Always JSON → script.
- Never edit formatting in the JSON; edit `build_awp.py` once if the firm template changes.
- Keep one example JSON attached every time – it calibrates depth and tone far better than instructions.
- If the model cannot search the web in your tenant, paste research notes into OTHER CONTEXT; the prompt still works.
- Version-control `build_awp.py` and the prompt in your team SharePoint; treat example JSONs as a growing library (each finished audit becomes a new example).

## Optional: Copilot Agent
Create a "AWP Builder" agent in Agent Builder with `AWP_Master_Prompt.md` as instructions and the four kit files in its knowledge. Enable web search and code interpreter. Users then only supply the INPUTS.

## Local fallback (no Copilot sandbox)
`pip install openpyxl` then `python build_awp.py your_content.json`. Python in Excel is not needed.
