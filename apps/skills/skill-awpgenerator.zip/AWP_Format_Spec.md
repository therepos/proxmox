# AWP Template Format Specification (100 / 200 / 300 series)

Derived from the firm's sample workpaper (NRF Facilities Management). `build_awp.py` implements all of this; this page is for reviewers and for anyone who must rebuild the script in another tool (Office Script, VBA).

## Workbook structure
| Tab | Purpose | Layout |
|---|---|---|
| Scope | Key processes vs indicative areas of focus vs Covered? | 4 cols; process merged down its areas; Covered? = Yes/N/A (yellow) |
| A | Index + engagement header (Client / Process / Audit period) + legend | B3:B5 are the single source; all other tabs link via `=A!B3` etc. |
| A100 | Risk & Control Matrix | S/N · Sub-process · Risk · Control No. · Finding for Design Effectiveness · Audit Strategy · Testing Result · WP Ref. Section rows merged A:H light-blue. Audit Strategy/Testing Result merged down all rows sharing one test. |
| A200 | Walkthrough index | No · title · Ref (A201…) |
| A201–A2nn | One per sub-process | Title bar (dark grey, white text) · Background (merged, yellow) · table: No. · Activity · Performed By · Frequency · Control Reference No. · Existing controls · Control Owner · Classification · Type · Finding for design effectiveness · Walkthrough Document. Section sub-headers merged A:K. "Please refer to <A302>" rows merged B:K, no control ref. |
| A300 | Testing index | No · title (formula `='A301'!B7`) · Ref |
| A301–A3nn | One per test | Rows: 7 Test n/Title · 9 Objective · 11 Basis of Selection · 13 Population · 15 Sample Size · 17 Source · 19 Audit Steps · 21 Work done table · Notes · Findings · Conclusion |
| DA | Data analytics register | Ref · Analytic · Procedure · Data required · Linked test · Result · WP ref |
| Ref-Reg | Auditor regulatory / standards reference list | No · Item · Body · Relevance |

## Numbering conventions
- Control refs: `A2nn-k`, k = sequential count of control activities in that walkthrough sheet (cross-reference rows excluded). Shown bold, centred, in the RCM "Control No." column one per line.
- Tests: `Test n` ↔ sheet `A3(00+n)`. RCM "WP Ref" = test sheet. Audit-strategy text in the RCM is the same text as "Audit Steps" on the test sheet.
- Work-done attribute columns numbered 1..k = the numbered audit steps; filled Y / N / N/A.

## Styles
| Element | Style |
|---|---|
| All text | Arial 8; wrap; vertical top |
| Table headers | Bold, grey fill `D9D9D9`, centred |
| Section rows / work-done headers | Light blue `DDEBF7` |
| Sheet title bars (Test n, Subprocess title, DA) | Dark grey `808080`, white bold text |
| WP ref tag (top-right cell, row 1) | Yellow `FFFF00`, bold, double border |
| Audit-step attribute columns | Green `92D050` |
| Cells to be completed in fieldwork | Light yellow `FFF2CC` |
| Borders | Thin all sides on table cells |
| Gridlines | Off |
| Freeze panes | A100 at C8; walkthroughs at C10; tests at C23 |

## Placeholder text (must be present in a blank AWP)
- "To be updated post walkthrough" (RCM design-effectiveness), "To be updated post testing" (RCM result), "To be updated" (walkthrough findings/docs, test notes/findings/conclusion), "[Expected control – validate/replace]" prefix on every expected control.
