#!/usr/bin/env python3
"""
build_awp.py – Build an Internal Audit Work Program (AWP) workbook in the
100/200/300-series template format from a JSON content file.

Usage:
    python build_awp.py awp_content.json            # writes <meta.output_filename>
    python build_awp.py awp_content.json out.xlsx   # explicit output path

The JSON must conform to awp_schema.json. This script owns ALL formatting;
the JSON owns ALL audit content. Do not put formatting in the JSON.
"""
import json, sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.utils.cell import range_boundaries

# ----------------------------- styles (template conventions) -----------------------------
def F(bold=False, italic=False, color="000000"):
    return Font(name="Arial", size=8, bold=bold, italic=italic, color=color)
FILL_HDR   = PatternFill("solid", fgColor="D9D9D9")  # grey table header
FILL_SEC   = PatternFill("solid", fgColor="DDEBF7")  # light-blue section / work-done header
FILL_TITLE = PatternFill("solid", fgColor="808080")  # dark-grey title bar (white text)
FILL_REF   = PatternFill("solid", fgColor="FFFF00")  # yellow WP ref tag (top-right)
FILL_ATTR  = PatternFill("solid", fgColor="92D050")  # green audit-step attribute columns
FILL_INPUT = PatternFill("solid", fgColor="FFF2CC")  # light-yellow: to be completed in fieldwork
thin = Side(style="thin"); dbl = Side(style="double")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
AL_TOP  = Alignment(vertical="top", wrap_text=True)
AL_CTR  = Alignment(horizontal="center", vertical="center", wrap_text=True)
AL_CTOP = Alignment(horizontal="center", vertical="top", wrap_text=True)
WHITE = "FFFFFF"

def base(ws):
    ws.sheet_view.showGridLines = False
def cell(ws, ref, v, bold=False, fill=None, al=AL_TOP, border=True, color="000000"):
    c = ws[ref]; c.value = v; c.font = F(bold, False, color); c.alignment = al
    if fill: c.fill = fill
    if border: c.border = BORDER
    return c
def plain(ws, ref, v, bold=False, fill=None):
    c = ws[ref]; c.value = v; c.font = F(bold); c.alignment = Alignment(vertical="top")
    if fill: c.fill = fill
    return c
def widths(ws, d):
    for k, v in d.items(): ws.column_dimensions[k].width = v
def header_block(ws, tag, tag_col, client_label="Client", period_label="Audit period"):
    c = ws[f"{tag_col}1"]; c.value = tag; c.font = F(True); c.fill = FILL_REF; c.alignment = AL_CTR
    c.border = Border(left=dbl, right=dbl, top=dbl, bottom=dbl)
    plain(ws, "A3", client_label, True); plain(ws, "B3", "=A!B3")
    plain(ws, "A4", "Process", True);     plain(ws, "B4", "=A!B4")
    plain(ws, "A5", period_label, True);  plain(ws, "B5", "=A!B5")
def table_header(ws, row, cols, fill=FILL_HDR):
    for i, h in enumerate(cols): cell(ws, f"{L(1+i)}{row}", h, True, fill, AL_CTR)
def merge_write(ws, rng, v, bold=False, fill=None, al=AL_TOP, color="000000"):
    ws.merge_cells(rng); first = rng.split(":")[0]
    cell(ws, first, v, bold, fill, al, color=color)
    c1, r1, c2, r2 = range_boundaries(rng)
    for r in range(r1, r2+1):
        for c in range(c1, c2+1):
            ws.cell(row=r, column=c).border = BORDER
            if fill: ws.cell(row=r, column=c).fill = fill
def title_bar(ws, row, left, right):
    cell(ws, f"A{row}", left, True, FILL_TITLE, AL_TOP, color=WHITE)
    cell(ws, f"B{row}", right, True, FILL_TITLE, AL_TOP, color=WHITE)

# ----------------------------- validation -----------------------------
def validate(d):
    errs = []
    ctrl_refs = set()
    for w in d["walkthroughs"]:
        n = 0
        for sec in w["sections"]:
            for a in sec["activities"]:
                if not a.get("cross_reference"):
                    n += 1; ctrl_refs.add(f"{w['ref']}-{n}")
    test_refs = {t["ref"] for t in d["tests"]}
    rcm_wp, rcm_strategy_refs = set(), set()
    for sec in d["rcm"]:
        for row in sec["rows"]:
            for r in row.get("control_refs") or []:
                if r not in ctrl_refs: errs.append(f"RCM control ref {r} not found in walkthroughs")
            if row.get("wp_ref"):
                rcm_wp.add(row["wp_ref"])
                if row.get("audit_strategy"): rcm_strategy_refs.add(row["wp_ref"])
    for t in test_refs:
        if t not in rcm_strategy_refs: errs.append(f"Test {t} has no audit_strategy row in RCM")
    for wp in rcm_wp:
        if wp not in test_refs and wp != "-": errs.append(f"RCM WP ref {wp} has no test sheet")
    for t in d["tests"]:
        for wd in [t["work_done"]] + ([t["work_done_2"]] if t.get("work_done_2") else []):
            if not (1 <= wd["attributes"] <= 12): errs.append(f"{t['ref']}: attributes must be 1-12")
    return errs, len(ctrl_refs)

# ----------------------------- builder -----------------------------
def build(d, out):
    wb = Workbook(); wb.remove(wb.active)
    m = d["meta"]

    # ---- Scope
    ws = wb.create_sheet("Scope"); base(ws)
    widths(ws, {"A": 6, "B": 45, "C": 95, "D": 30})
    table_header(ws, 1, ["No", "Key Process", "Indicative area of focus", "Covered?"])
    r = 2
    for i, s in enumerate(d["scope"], 1):
        start = r
        for it in s["areas"]:
            cell(ws, f"C{r}", it); cell(ws, f"D{r}", "Yes", fill=FILL_INPUT, al=AL_CTOP); r += 1
        end = r - 1
        if end > start:
            merge_write(ws, f"A{start}:A{end}", i, al=AL_CTOP); merge_write(ws, f"B{start}:B{end}", s["key_process"])
        else:
            cell(ws, f"A{start}", i, al=AL_CTOP); cell(ws, f"B{start}", s["key_process"])
    if m.get("scope_note"): plain(ws, f"A{r+1}", m["scope_note"])
    ws.freeze_panes = "A2"

    # ---- A (index)
    ws = wb.create_sheet("A"); base(ws)
    widths(ws, {"A": 12, "B": 64, "C": 8, "D": 12, "E": 8, "F": 8, "G": 14})
    c = ws["G1"]; c.value = "A"; c.font = F(True); c.fill = FILL_REF; c.alignment = AL_CTR
    plain(ws, "A3", "Client", True); plain(ws, "B3", m["client"])
    plain(ws, "A4", "Process", True); plain(ws, "B4", m["process"])
    plain(ws, "A5", "Audit period ", True); plain(ws, "B5", m["audit_period"], fill=FILL_INPUT)
    plain(ws, "B7", "Index", True); plain(ws, "G7", "Ref", True)
    for i, (t, ref) in enumerate([("Risk and control matrix", "A100"), ("Process walkthrough", "A200"), ("Testing of controls", "A300"), ("Data Analytics", "DA")]):
        rr = 9 + 2*i; plain(ws, f"A{rr}", i+1); plain(ws, f"B{rr}", t); plain(ws, f"G{rr}", ref, True)
    plain(ws, "B18", "Legend", True)
    ws["A19"].fill = FILL_INPUT; ws["A19"].border = BORDER
    plain(ws, "B19", "Light-yellow cells = to be completed / updated during planning, walkthrough and fieldwork (client-specific facts, sample details, results).")
    ws["A20"].fill = FILL_ATTR; ws["A20"].border = BORDER
    plain(ws, "B20", "Green columns in 300-series 'Work done' tables = audit step attributes; record Y / N / N/A per sample against the numbered audit step.")
    plain(ws, "B21", "Control descriptions in 200-series are EXPECTED controls (leading practice) drafted pre-walkthrough; replace with actual client controls observed and record design gaps in 'Finding for design effectiveness'.")
    plain(ws, "B22", "Sample sizes are indicative and to be re-based once populations are obtained; obtain system-generated population listings and document completeness checks.")
    plain(ws, "B23", "Prepared by: [ ]      Reviewed by: [ ]      Date: [ ]")

    # ---- A100 (RCM)
    ws = wb.create_sheet("A100"); base(ws)
    widths(ws, {"A": 10, "B": 40, "C": 62, "D": 12, "E": 40, "F": 80, "G": 30, "H": 10})
    header_block(ws, "A100", "H", "Client:", "Review period:")
    table_header(ws, 7, ["S/N", "Sub-process", "Risk", "Control No.", "Finding for Design Effectiveness", "Audit Strategy", "Testing Result", "WP Ref"])
    r, sn = 8, 0
    for sec in d["rcm"]:
        merge_write(ws, f"A{r}:H{r}", sec["section"], True, FILL_SEC); r += 1
        grp = None
        for row in sec["rows"]:
            sn += 1
            cell(ws, f"A{r}", sn, al=AL_CTOP); cell(ws, f"B{r}", row["subprocess"]); cell(ws, f"C{r}", row["risk"])
            cell(ws, f"D{r}", "\n".join(row["control_refs"]) if row.get("control_refs") else "-", True, al=AL_CTOP)
            cell(ws, f"E{r}", "To be updated post walkthrough", fill=FILL_INPUT)
            cell(ws, f"H{r}", row.get("wp_ref", "-"), True, al=AL_CTOP)
            if row.get("audit_strategy"):
                if grp is not None and grp < r-1: ws.merge_cells(f"F{grp}:F{r-1}"); ws.merge_cells(f"G{grp}:G{r-1}")
                grp = r; cell(ws, f"F{r}", row["audit_strategy"]); cell(ws, f"G{r}", "To be updated post testing", fill=FILL_INPUT)
            else:
                cell(ws, f"F{r}", None); cell(ws, f"G{r}", None, fill=FILL_INPUT)
            r += 1
        if grp is not None and grp < r-1: ws.merge_cells(f"F{grp}:F{r-1}"); ws.merge_cells(f"G{grp}:G{r-1}")
    ws.freeze_panes = "C8"

    # ---- A200 (walkthrough index)
    ws = wb.create_sheet("A200"); base(ws)
    widths(ws, {"A": 12, "B": 70, "C": 8, "D": 7, "E": 7, "F": 7, "G": 11})
    header_block(ws, "A200", "G")
    plain(ws, "B7", "Process walkthrough", True); plain(ws, "G7", "Ref ", True)
    for i, w in enumerate(d["walkthroughs"]):
        rr = 9 + 2*i; plain(ws, f"A{rr}", i+1); plain(ws, f"B{rr}", w["title"]); plain(ws, f"G{rr}", w["ref"], True)

    # ---- A201.. (walkthroughs)
    WCOLS = ["No.", "Activity", "Performed By", "Frequency", "Control Reference No.", "Existing controls / mitigating measures", "Control Owner", "Control Classification", "Control Type", "Finding for design effectiveness", "Walkthrough Document"]
    for w in d["walkthroughs"]:
        ws = wb.create_sheet(w["ref"]); base(ws)
        widths(ws, {"A": 10, "B": 48, "C": 18, "D": 16, "E": 12, "F": 70, "G": 18, "H": 14, "I": 13, "J": 40, "K": 20})
        header_block(ws, w["ref"], "K")
        merge_write(ws, "A7:K7", f"Subprocess title: {w['title']}", True, FILL_TITLE, color=WHITE)
        merge_write(ws, "A8:K8", "Background:\n\n" + w["background"], fill=FILL_INPUT)
        ws.row_dimensions[8].height = max(60, 11 * (w["background"].count("\n") + len(w["background"]) // 220 + 3))
        table_header(ws, 9, WCOLS)
        r, cn = 10, 0
        for sec in w["sections"]:
            merge_write(ws, f"A{r}:K{r}", sec["title"], True); r += 1
            for n, a in enumerate(sec["activities"], 1):
                if a.get("cross_reference"):
                    cell(ws, f"A{r}", n, al=AL_CTOP); merge_write(ws, f"B{r}:K{r}", a["activity"]); r += 1; continue
                cn += 1
                cell(ws, f"A{r}", n, al=AL_CTOP); cell(ws, f"B{r}", a["activity"])
                cell(ws, f"C{r}", a.get("performed_by"), fill=FILL_INPUT); cell(ws, f"D{r}", a.get("frequency"), fill=FILL_INPUT)
                cell(ws, f"E{r}", f"{w['ref']}-{cn}", True, al=AL_CTOP)
                cell(ws, f"F{r}", "[Expected control – validate/replace] " + a["expected_control"], fill=FILL_INPUT)
                cell(ws, f"G{r}", a.get("owner"), fill=FILL_INPUT); cell(ws, f"H{r}", a.get("classification"), fill=FILL_INPUT); cell(ws, f"I{r}", a.get("type"), fill=FILL_INPUT)
                cell(ws, f"J{r}", "To be updated", fill=FILL_INPUT); cell(ws, f"K{r}", "To be updated", fill=FILL_INPUT)
                r += 1
        ws.freeze_panes = "C10"

    # ---- A300 (test index)
    ws = wb.create_sheet("A300"); base(ws)
    widths(ws, {"A": 12, "B": 70, "C": 8, "D": 7, "E": 11})
    header_block(ws, "A300", "E")
    plain(ws, "B7", "Testing of controls", True); plain(ws, "E7", "Ref ", True)
    for i, t in enumerate(d["tests"]):
        rr = 9 + 2*i; plain(ws, f"A{rr}", i+1); plain(ws, f"B{rr}", f"='{t['ref']}'!B7"); plain(ws, f"E{rr}", t["ref"], True)
    rr = 9 + 2*len(d["tests"]); plain(ws, f"A{rr}", len(d["tests"])+1); plain(ws, f"B{rr}", "Data analytics procedures"); plain(ws, f"E{rr}", "DA", True)

    # ---- A301.. (tests)
    strategy = {}
    for sec in d["rcm"]:
        for row in sec["rows"]:
            if row.get("audit_strategy") and row.get("wp_ref"): strategy.setdefault(row["wp_ref"], row["audit_strategy"])

    def work_table(ws, r, wd, nrows):
        cols, nattr = wd["columns"], wd["attributes"]; ncol = len(cols); a1 = 3 + ncol
        merge_write(ws, f"B{r}:{L(2+ncol)}{r}", wd["title"], True, FILL_SEC)
        merge_write(ws, f"{L(a1)}{r}:{L(a1+nattr-1)}{r}", "Audit steps", True, FILL_ATTR, AL_CTR)
        cell(ws, f"{L(a1+nattr)}{r}", "Remarks / exception", True, FILL_SEC, AL_CTR); r += 1
        cell(ws, f"B{r}", "S/N", True, FILL_SEC, AL_CTR)
        for i, h in enumerate(cols): cell(ws, f"{L(3+i)}{r}", h, True, FILL_SEC, AL_CTR)
        for i in range(nattr): cell(ws, f"{L(a1+i)}{r}", i+1, True, FILL_ATTR, AL_CTR)
        cell(ws, f"{L(a1+nattr)}{r}", "", True, FILL_SEC, AL_CTR); r += 1
        for n in range(1, nrows+1):
            cell(ws, f"B{r}", n, al=AL_CTOP)
            for i in range(ncol): cell(ws, f"{L(3+i)}{r}", None, fill=FILL_INPUT)
            for i in range(nattr): cell(ws, f"{L(a1+i)}{r}", None, fill=FILL_INPUT, al=AL_CTOP)
            cell(ws, f"{L(a1+nattr)}{r}", None, fill=FILL_INPUT); r += 1
        return r

    for t in d["tests"]:
        ws = wb.create_sheet(t["ref"]); base(ws)
        wd = t["work_done"]; ncol = len(wd["columns"]); nattr = wd["attributes"]; last = 3 + ncol + nattr
        widths(ws, {"A": 18, "B": 6})
        for i in range(ncol): ws.column_dimensions[L(3+i)].width = 20
        for i in range(nattr): ws.column_dimensions[L(3+ncol+i)].width = 5
        ws.column_dimensions[L(last)].width = 30
        header_block(ws, t["ref"], L(last))
        title_bar(ws, 7, t["num"], t["title"]); ws.merge_cells(f"B7:{L(min(last,8))}7")
        plain(ws, "A9", "Objective: ", True); ws.merge_cells(f"B9:{L(min(last,8))}9"); ws["B9"].value = t["objective"]; ws["B9"].font = F(); ws["B9"].alignment = AL_TOP
        ws.row_dimensions[9].height = 24
        plain(ws, "A11", "Basis of Selection:", True); plain(ws, "B11", t["basis"], fill=FILL_INPUT)
        plain(ws, "A13", "Population:", True); plain(ws, "B13", t["population"], fill=FILL_INPUT)
        plain(ws, "A15", "Sample Size:", True); plain(ws, "B15", t["sample"], fill=FILL_INPUT)
        plain(ws, "A17", "Source:", True); plain(ws, "B17", t["source"], fill=FILL_INPUT)
        plain(ws, "A19", "Audit Steps:", True)
        steps = t.get("audit_steps") or strategy.get(t["ref"], "")
        ws.merge_cells(f"B19:{L(min(last,8))}19"); ws["B19"].value = steps; ws["B19"].font = F(); ws["B19"].alignment = AL_TOP
        ws.row_dimensions[19].height = max(60, 12 * (steps.count("\n") + 2))
        plain(ws, "A21", "Work done:", True)
        nrows = wd.get("rows") or 10
        r = work_table(ws, 21, wd, nrows)
        if t.get("work_done_2"):
            r += 1; r = work_table(ws, r, t["work_done_2"], t["work_done_2"].get("rows") or 10)
        r += 1
        plain(ws, f"A{r}", "Notes:", True); plain(ws, f"B{r}", "To be updated", fill=FILL_INPUT); r += 2
        plain(ws, f"A{r}", "Findings:", True); plain(ws, f"B{r}", "To be updated", fill=FILL_INPUT); r += 1
        plain(ws, f"A{r}", "Conclusion:", True); plain(ws, f"B{r}", "To be updated", fill=FILL_INPUT)
        ws.freeze_panes = "C23"

    # ---- DA
    ws = wb.create_sheet("DA"); base(ws)
    widths(ws, {"A": 8, "B": 34, "C": 80, "D": 40, "E": 12, "F": 30, "G": 30})
    header_block(ws, "DA", "G")
    title_bar(ws, 7, "DA", "Data analytics procedures (preliminary and fieldwork)")
    table_header(ws, 9, ["Ref", "Analytic", "Procedure", "Data required (system-generated, with completeness check)", "Linked test", "Result / exceptions", "WP ref / status"])
    for i, a in enumerate(d["data_analytics"]):
        r = 10 + i
        cell(ws, f"A{r}", a["ref"], True, al=AL_CTOP); cell(ws, f"B{r}", a["name"]); cell(ws, f"C{r}", a["procedure"]); cell(ws, f"D{r}", a["data_required"])
        cell(ws, f"E{r}", a["linked_test"], al=AL_CTOP); cell(ws, f"F{r}", "To be updated", fill=FILL_INPUT); cell(ws, f"G{r}", "To be updated", fill=FILL_INPUT)
    ws.freeze_panes = "A10"

    # ---- Ref-Reg
    if d.get("reference_list"):
        ws = wb.create_sheet("Ref-Reg"); base(ws)
        widths(ws, {"A": 6, "B": 70, "C": 18, "D": 90})
        title_bar(ws, 1, "Ref", m.get("reference_title", "Auditor reference list – regulations, standards and leading practice (to be validated with client Legal/Compliance)"))
        table_header(ws, 3, ["No", "Regulation / code / standard", "Regulator / body", "Key requirement relevant to the audit"])
        for i, x in enumerate(d["reference_list"], 1):
            r = 3 + i; cell(ws, f"A{r}", i, al=AL_CTOP); cell(ws, f"B{r}", x["item"]); cell(ws, f"C{r}", x["body"]); cell(ws, f"D{r}", x["relevance"])
        plain(ws, f"A{5+len(d['reference_list'])}", "Note: Compiled from public sources by the auditor; not legal advice. Validate currency and applicability with client Legal/Compliance during planning.")

    wb.save(out)

if __name__ == "__main__":
    if len(sys.argv) < 2: sys.exit(__doc__)
    d = json.load(open(sys.argv[1], encoding="utf-8"))
    errs, nctrl = validate(d)
    if errs:
        print("VALIDATION ERRORS (fix the JSON before building):"); [print(" -", e) for e in errs]; sys.exit(1)
    out = sys.argv[2] if len(sys.argv) > 2 else d["meta"].get("output_filename", "AWP.xlsx")
    build(d, out)
    print(f"Built {out}: {len(d['scope'])} scope areas, {len(d['walkthroughs'])} walkthroughs, {nctrl} controls, "
          f"{sum(len(s['rows']) for s in d['rcm'])} RCM rows, {len(d['tests'])} tests, {len(d['data_analytics'])} analytics.")
