// ETC Hours Extractor - Content Script
// Extracts resourcing table data from SAP UI5 Fiori ETC application

(function () {
  "use strict";

  /**
   * Extracts text content from a SAP UI5 table cell, skipping hidden placeholders.
   */
  function getCellText(cell) {
    if (!cell) return "";
    // Get all visible text elements (skip hidden placeholders)
    const hiddenSelectors =
      ".sapUiHiddenPlaceholder, [aria-hidden='true'], .sapUiInvisibleText";
    const clone = cell.cloneNode(true);
    clone.querySelectorAll(hiddenSelectors).forEach((el) => el.remove());

    // For input fields, grab the value
    const input = cell.querySelector("input.sapMInputBaseInner");
    if (input) return input.value || "";

    return (clone.textContent || "").trim().replace(/\s+/g, " ");
  }

  /**
   * Attempts to find the resourcing table in the DOM.
   * Looks for known SAP UI5 element IDs and class patterns.
   */
  function findResourcingTable() {
    // Try exact ID match first
    let table = document.querySelector(
      '[id*="resourcingTbl"] table.sapMListTbl'
    );
    if (table) return table;

    // Fallback: look for any sap.m.Table with the resource table class
    table = document.querySelector("table.sapMListTbl");
    return table;
  }

  /**
   * Extracts column headers from the table.
   */
  function extractHeaders(table) {
    const headerRow = table.querySelector("thead tr.sapMListTblHeader");
    if (!headerRow) return [];

    const headers = [];
    const cells = headerRow.querySelectorAll("th.sapMListTblHeaderCell");

    cells.forEach((cell) => {
      // Extract all label text from the header cell
      const labels = cell.querySelectorAll(
        ".sapMLabel:not(.sapMLabelNoText) .sapMLabelTextWrapper bdi"
      );
      let headerText = "";
      labels.forEach((lbl) => {
        const t = (lbl.textContent || "").trim();
        if (t) headerText += (headerText ? " - " : "") + t;
      });

      // Fallback to general text extraction
      if (!headerText) {
        headerText = getCellText(cell);
      }

      headers.push(headerText || `Column ${headers.length + 1}`);
    });

    return headers;
  }

  /**
   * Extracts data rows from the table body.
   */
  function extractRows(table) {
    const tbody = table.querySelector("tbody.sapMTableTBody");
    if (!tbody) return [];

    const rows = [];
    const trs = tbody.querySelectorAll("tr.sapMListTblRow");

    trs.forEach((tr) => {
      const cells = tr.querySelectorAll("td.sapMListTblCell");
      const rowData = [];

      cells.forEach((cell) => {
        // Skip the action/button column (last column with delete buttons)
        const colId = cell.getAttribute("data-sap-ui-column") || "";
        if (colId.includes("__column9")) return; // Skip actions column

        rowData.push(getCellText(cell));
      });

      if (rowData.length > 0 && rowData.some((v) => v !== "")) {
        rows.push(rowData);
      }
    });

    return rows;
  }

  /**
   * Extracts footer/totals row.
   */
  function extractFooter(table) {
    const footerRow = table.querySelector("tfoot tr.sapMListTblFooter");
    if (!footerRow) return null;

    const cells = footerRow.querySelectorAll("td.sapMListTblFooterCell");
    const footerData = [];

    cells.forEach((cell) => {
      const colId = cell.getAttribute("data-sap-ui-column") || "";
      if (colId.includes("__column9")) return;
      footerData.push(getCellText(cell));
    });

    return footerData.some((v) => v !== "") ? footerData : null;
  }

  /**
   * Main extraction function.
   */
  function extractTableData() {
    const table = findResourcingTable();
    if (!table) {
      return {
        success: false,
        error:
          "Could not find the resourcing table. Make sure you are on the ETC page with the My Team table visible.",
      };
    }

    const headers = extractHeaders(table);
    const rows = extractRows(table);
    const footer = extractFooter(table);

    // Filter out the actions column from headers too
    const cleanHeaders = headers.filter(
      (_, i) => i < headers.length - 1 || headers[i] !== ""
    );

    return {
      success: true,
      headers: cleanHeaders,
      rows: rows,
      footer: footer,
      extractedAt: new Date().toISOString(),
      rowCount: rows.length,
    };
  }

  /**
   * Converts extracted data to CSV format.
   */
  function toCSV(data) {
    if (!data.success) return "";

    const escape = (val) => {
      const str = String(val || "");
      if (str.includes(",") || str.includes('"') || str.includes("\n")) {
        return '"' + str.replace(/"/g, '""') + '"';
      }
      return str;
    };

    let csv = data.headers.map(escape).join(",") + "\n";
    data.rows.forEach((row) => {
      csv += row.map(escape).join(",") + "\n";
    });
    if (data.footer) {
      csv += data.footer.map(escape).join(",") + "\n";
    }
    return csv;
  }

  /**
   * Converts extracted data to JSON format.
   */
  function toJSON(data) {
    if (!data.success) return "{}";

    const result = data.rows.map((row) => {
      const obj = {};
      data.headers.forEach((header, i) => {
        obj[header] = row[i] || "";
      });
      return obj;
    });

    return JSON.stringify(
      {
        extractedAt: data.extractedAt,
        rowCount: data.rowCount,
        data: result,
        totals: data.footer
          ? (() => {
              const obj = {};
              data.headers.forEach((header, i) => {
                if (data.footer[i]) obj[header] = data.footer[i];
              });
              return obj;
            })()
          : null,
      },
      null,
      2
    );
  }

  // Listen for messages from the popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "extract") {
      const data = extractTableData();
      sendResponse(data);
    } else if (request.action === "extractCSV") {
      const data = extractTableData();
      sendResponse({ success: data.success, csv: toCSV(data), error: data.error });
    } else if (request.action === "extractJSON") {
      const data = extractTableData();
      sendResponse({
        success: data.success,
        json: toJSON(data),
        error: data.error,
      });
    } else if (request.action === "ping") {
      sendResponse({ alive: true });
    }
    return true; // Keep channel open for async
  });
})();
