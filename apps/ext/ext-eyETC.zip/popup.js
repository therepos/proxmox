// ETC Hours Extractor - Popup Script

let lastData = null;

const $ = (sel) => document.querySelector(sel);
const statusEl = $("#status");
const statusText = $("#statusText");
const btnExtract = $("#btnExtract");
const btnCSV = $("#btnCSV");
const btnJSON = $("#btnJSON");
const btnClipboard = $("#btnClipboard");
const btnExcel = $("#btnExcel");
const previewSection = $("#previewSection");
const previewTable = $("#previewTable");

function setStatus(type, msg) {
  statusEl.className = `status ${type}`;
  statusText.textContent = msg;
}

function enableExports(enabled) {
  btnCSV.disabled = !enabled;
  btnJSON.disabled = !enabled;
  btnClipboard.disabled = !enabled;
  btnExcel.disabled = !enabled;
}

function renderPreview(data) {
  if (!data || !data.success) {
    previewSection.classList.add("hidden");
    return;
  }

  let html = "<thead><tr>";
  data.headers.forEach((h) => {
    html += `<th>${escapeHtml(h)}</th>`;
  });
  html += "</tr></thead><tbody>";

  data.rows.forEach((row) => {
    html += "<tr>";
    row.forEach((cell) => {
      html += `<td>${escapeHtml(cell)}</td>`;
    });
    html += "</tr>";
  });

  if (data.footer) {
    html += '<tr class="footer-row">';
    data.footer.forEach((cell) => {
      html += `<td>${escapeHtml(cell)}</td>`;
    });
    html += "</tr>";
  }

  html += "</tbody>";
  previewTable.innerHTML = html;
  previewSection.classList.remove("hidden");
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str || "";
  return div.innerHTML;
}

function downloadFile(content, filename, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function dataToCSV(data) {
  const escape = (val) => {
    const str = String(val || "");
    if (str.includes(",") || str.includes('"') || str.includes("\n")) {
      return '"' + str.replace(/"/g, '""') + '"';
    }
    return str;
  };
  let csv = data.headers.map(escape).join(",") + "\n";
  data.rows.forEach((row) => (csv += row.map(escape).join(",") + "\n"));
  if (data.footer) csv += data.footer.map(escape).join(",") + "\n";
  return csv;
}

function dataToTSV(data) {
  let tsv = data.headers.join("\t") + "\n";
  data.rows.forEach((row) => (tsv += row.join("\t") + "\n"));
  if (data.footer) tsv += data.footer.join("\t") + "\n";
  return tsv;
}

function dataToJSON(data) {
  const result = data.rows.map((row) => {
    const obj = {};
    data.headers.forEach((h, i) => (obj[h] = row[i] || ""));
    return obj;
  });
  return JSON.stringify(
    { extractedAt: data.extractedAt, rowCount: data.rowCount, data: result },
    null,
    2
  );
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function sendMessage(tab, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tab.id, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

// ── Extract ──
btnExtract.addEventListener("click", async () => {
  btnExtract.disabled = true;
  btnExtract.innerHTML = '<span class="spinner"></span> Extracting…';
  setStatus("info", "Scanning page for resourcing table…");

  try {
    const tab = await getActiveTab();

    // Try to inject content script if not already present
    try {
      await sendMessage(tab, { action: "ping" });
    } catch {
      // Content script not loaded yet, inject it
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"],
      });
      // Small delay for injection
      await new Promise((r) => setTimeout(r, 300));
    }

    const data = await sendMessage(tab, { action: "extract" });

    if (data && data.success) {
      lastData = data;
      setStatus(
        "success",
        `Extracted ${data.rowCount} rows at ${new Date(data.extractedAt).toLocaleTimeString()}`
      );
      enableExports(true);
      renderPreview(data);
    } else {
      setStatus("error", data?.error || "No data found on this page.");
      enableExports(false);
      previewSection.classList.add("hidden");
    }
  } catch (err) {
    setStatus(
      "error",
      "Could not connect to the page. Try refreshing the page and clicking Extract again."
    );
    console.error(err);
    enableExports(false);
  }

  btnExtract.disabled = false;
  btnExtract.innerHTML = '<span class="icon">📊</span> Extract Table Data';
});

// ── Download CSV ──
btnCSV.addEventListener("click", () => {
  if (!lastData) return;
  const csv = dataToCSV(lastData);
  const timestamp = new Date().toISOString().slice(0, 10);
  downloadFile(csv, `etc-hours-${timestamp}.csv`, "text/csv;charset=utf-8;");
  setStatus("success", "CSV downloaded!");
});

// ── Download JSON ──
btnJSON.addEventListener("click", () => {
  if (!lastData) return;
  const json = dataToJSON(lastData);
  const timestamp = new Date().toISOString().slice(0, 10);
  downloadFile(
    json,
    `etc-hours-${timestamp}.json`,
    "application/json;charset=utf-8;"
  );
  setStatus("success", "JSON downloaded!");
});

// ── Copy to Clipboard (plain text table) ──
btnClipboard.addEventListener("click", async () => {
  if (!lastData) return;
  const tsv = dataToTSV(lastData);
  try {
    await navigator.clipboard.writeText(tsv);
    setStatus("success", "Copied to clipboard! Paste into any app.");
    btnClipboard.innerHTML = '<span class="icon">✅</span> Copied!';
    setTimeout(() => {
      btnClipboard.innerHTML = '<span class="icon">📋</span> Copy to Clipboard';
    }, 2000);
  } catch {
    setStatus("error", "Clipboard access denied.");
  }
});

// ── Copy for Excel (TSV - pastes directly into cells) ──
btnExcel.addEventListener("click", async () => {
  if (!lastData) return;
  const tsv = dataToTSV(lastData);
  try {
    await navigator.clipboard.writeText(tsv);
    setStatus(
      "success",
      "Copied! Open Excel → select cell A1 → Ctrl+V to paste into cells."
    );
    btnExcel.innerHTML = '<span class="icon">✅</span> Copied!';
    setTimeout(() => {
      btnExcel.innerHTML = '<span class="icon">📗</span> Copy for Excel';
    }, 2000);
  } catch {
    setStatus("error", "Clipboard access denied.");
  }
});
