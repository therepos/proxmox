# NotebookLM Bulk Delete

Deletes all notebooks visible on your Gemini Notebook / NotebookLM list page.

## Install
1. Unzip this folder somewhere permanent.
2. Chrome → `chrome://extensions` → toggle **Developer mode** (top right).
3. **Load unpacked** → select this folder.

## Use
1. Go to https://notebook.google.com/ and make sure you are on the notebook
   **list** (not inside a notebook). Scroll to the bottom first so every
   notebook is loaded — it only sees what the page has rendered.
2. Click the extension icon → **Scan notebooks** → review the list.
3. Type `DELETE` → click **Delete all**.
4. Keep the tab open and in the foreground. Closing the popup is fine.

## Notes
- Deletion is permanent. There is no undo and no trash.
- It deletes notebooks you own. Shared notebooks you do not own may fail.
- ~0.7s pause between deletions to avoid rate limiting.
- It stops on the first failure and reports which notebook it stopped on.
- Selectors are based on the current UI (`aria-label="Project actions menu"`,
  English interface). If Google changes the markup, scan will return 0 and
  nothing will happen.
