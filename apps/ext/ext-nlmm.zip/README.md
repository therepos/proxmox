# NotebookLM Tools

Bulk tools for the Gemini Notebook / NotebookLM notebook list page.
Currently ships one feature: **Bulk delete**.

## Install
1. Unzip this folder somewhere permanent.
2. Chrome → `chrome://extensions` → toggle **Developer mode** (top right).
3. **Load unpacked** → select this folder.
4. After updating the files, click the reload icon on the extension card.

## Use: Bulk delete
1. Go to https://notebook.google.com/ and make sure you are on the notebook
   **list** (not inside a notebook).
2. Click the extension icon → **Scan notebooks**. It scrolls the page to load
   every notebook, then shows the list.
3. Type `DELETE` → **Delete all**. **Stop** ends the run after the current one.
4. Keep the tab open and in the foreground. Closing the popup is fine;
   reopening it resumes the progress display.

Behaviour:
- Deletion is permanent. There is no undo and no trash.
- Each notebook is retried up to 3 times with back-off, then skipped and
  reported. One failure no longer aborts the whole run.
- Success is checked by the notebook disappearing from the list, not by a
  fixed element reference, so page re-renders do not break it.
- ~1s pause between deletions, growing to 8s if the page pushes back.
- Selectors target the current UI (`aria-label="Project actions menu"`,
  English interface). If Google changes the markup, scan returns 0 and
  nothing happens.

## Layout (adding a feature)
```
manifest.json
popup.html / popup.css          shell: header, feature tabs, log
popup/app.js                    framework: tab lookup, injection, page.*, poll()
popup/features/<name>.js        one file per feature: App.register({ id, title, render })
page/core.js                    injected helpers: rows, menus, dialogs, job runner (window.NLM)
page/actions/<name>.js          one file per page action: NLM.register(id, async (job, opts, N) => …)
```
To add a feature:
1. Create `page/actions/<name>.js` and add it to `PAGE_FILES` in `popup/app.js`.
2. Create `popup/features/<name>.js` and add a `<script>` tag for it in `popup.html`.
3. From the feature call `page.start('<name>', opts)` and `poll(...)` for status.
Tabs appear automatically once more than one feature is registered.
