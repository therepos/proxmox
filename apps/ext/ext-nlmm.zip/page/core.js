/* Injected into the NotebookLM tab (extension isolated world). Exposes
 * window.NLM: DOM helpers for the notebook list plus a tiny job runner.
 * Actions live in page/actions/*.js and call NLM.register(id, fn). */

(() => {
  if (window.NLM) return;

  const MENU_SEL = 'button[aria-label="Project actions menu"]';
  const ROW_SEL = 'tr, project-button, mat-card, [role="row"], [role="listitem"]';
  const TITLE_SEL = '.project-button-title, [class*="title"], td';

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (el) => (el && el.textContent || '').trim().replace(/\s+/g, ' ').toLowerCase();
  const visible = (el) => !!el && el.isConnected && el.getClientRects().length > 0;

  async function waitFor(fn, ms = 6000, step = 100) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      const v = fn();
      if (v) return v;
      await sleep(step);
    }
    return null;
  }

  /* ----- notebook rows ----- */

  const menuButtons = () => [...document.querySelectorAll(MENU_SEL)].filter(visible);

  function rowOf(btn) {
    const el = btn.closest(ROW_SEL) || btn.parentElement;
    const t = el && el.querySelector(TITLE_SEL);
    const name = ((t && t.textContent) || (el && el.textContent) || '')
      .trim().replace(/\s+/g, ' ').slice(0, 90) || '(untitled)';
    return { btn, el, name };
  }

  const rows = () => menuButtons().map(rowOf);
  const names = () => rows().map((r) => r.name);

  /* Scroll every scrollable container (and the window) to the bottom until the
   * row count stops growing, so lazily rendered notebooks get loaded. */
  async function loadAll(maxRounds = 30) {
    let last = -1;
    for (let i = 0; i < maxRounds; i++) {
      const n = menuButtons().length;
      if (n === last) break;
      last = n;
      window.scrollTo(0, document.documentElement.scrollHeight);
      document.querySelectorAll('*').forEach((el) => {
        const cs = getComputedStyle(el);
        if (/(auto|scroll)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 20) {
          el.scrollTop = el.scrollHeight;
        }
      });
      await sleep(400);
    }
    return menuButtons().length;
  }

  /* ----- overlays: menus, dialogs, snackbars ----- */

  function closeOverlays() {
    // Escape must start inside the overlay (focus is trapped there) to reach CDK's handler.
    const targets = new Set([document.activeElement, document.body].filter(Boolean));
    for (const t of targets) {
      for (const type of ['keydown', 'keyup']) {
        t.dispatchEvent(new KeyboardEvent(type, { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
      }
    }
    document.querySelectorAll('.cdk-overlay-backdrop').forEach((b) => b.click());
  }

  /* Open the row's action menu and return the panel that belongs to it. */
  async function openMenu(btn, ms = 4000) {
    btn.click();
    return waitFor(() => {
      const id = btn.getAttribute('aria-controls');
      const own = id && document.getElementById(id);
      if (visible(own)) return own;
      const panels = [...document.querySelectorAll('.mat-mdc-menu-panel, [role="menu"]')].filter(visible);
      return panels[panels.length - 1] || null;  // newest panel is last in the overlay container
    }, ms);
  }

  function menuItem(panel, test) {
    return [...panel.querySelectorAll('[role="menuitem"], button')].find((e) => test(norm(e))) || null;
  }

  /* Wait for a confirmation dialog and return the matching button (or null). */
  async function dialogButton(test, ms = 4000) {
    return waitFor(() => {
      const dlgs = [...document.querySelectorAll('[role="dialog"], [role="alertdialog"], mat-dialog-container')].filter(visible);
      const dlg = dlgs[dlgs.length - 1];
      if (!dlg) return null;
      return [...dlg.querySelectorAll('button')].find((b) => test(norm(b))) || null;
    }, ms);
  }

  function errorToast() {
    const t = [...document.querySelectorAll('mat-snack-bar-container, [role="alert"], [role="status"]')].filter(visible);
    const bad = t.find((e) => /(wrong|error|fail|try again|too many)/.test(norm(e)));
    return bad ? norm(bad) : null;
  }

  /* ----- job runner ----- */

  const actions = {};
  let job = null;

  const fresh = (id) => ({
    id, started: true, done: false, stopRequested: false, total: 0, current: '',
    deleted: [], failed: [], log: [],
  });

  function register(id, fn) { actions[id] = fn; }

  function start(id, opts = {}) {
    if (!actions[id]) return 'unknown action: ' + id;
    if (job && !job.done) return 'busy';
    job = fresh(id);
    (async () => {
      try { await actions[id](job, opts, api); }
      catch (e) { job.failed.push('fatal: ' + (e && e.message || e)); }
      finally { job.current = ''; job.done = true; }
    })();
    return 'started';
  }

  function status() {
    if (!job) return { started: false, done: true, total: 0, current: '', deleted: [], failed: [] };
    const { id, started, done, total, current, deleted, failed } = job;
    return { id, started, done, total, current, deleted, failed };
  }

  function stop() { if (job) job.stopRequested = true; return true; }

  async function scan() { await loadAll(); return names(); }

  const api = {
    MENU_SEL, sleep, norm, visible, waitFor,
    menuButtons, rowOf, rows, names, loadAll,
    closeOverlays, openMenu, menuItem, dialogButton, errorToast,
  };

  window.NLM = { ...api, register, start, status, stop, scan };
})();
