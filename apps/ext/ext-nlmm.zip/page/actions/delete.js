/* Action "delete": delete every notebook on the list page.
 *
 * Robustness rules (the v1 script stopped after a handful of notebooks):
 *  - never trust an element reference across a re-render; re-query each turn
 *  - only look at the menu panel / dialog that just opened, not stale ones
 *  - a failed notebook is retried with back-off, then skipped, never fatal
 *  - success = the notebook's name is gone or the row count dropped
 *  - re-scroll so lazily rendered notebooks get picked up too */

window.NLM.register('delete', async (job, opts, N) => {
  const MAX_TRIES = 3;
  const BASE_DELAY = opts.delay || 1000;
  const LIMIT = opts.limit || 5000;

  const isDelete = (t) => /\bdelete\b/.test(t) && !/collection|source/.test(t);
  const isConfirm = (t) => /^(delete|delete notebook|yes, delete|confirm|ok)$/.test(t);

  const tries = new Map();           // name -> failed attempts
  const skip = (name) => (tries.get(name) || 0) >= MAX_TRIES;
  let delay = BASE_DELAY;

  async function deleteOne(row) {
    const { btn, name } = row;
    const before = N.menuButtons().length;
    const oldToast = N.errorToast();          // ignore anything already on screen
    if (!N.visible(btn)) return 'row vanished before click';

    N.closeOverlays();
    const panel = await N.openMenu(btn);
    if (!panel) return 'menu did not open';

    const item = N.menuItem(panel, isDelete);
    if (!item) { N.closeOverlays(); return 'no Delete item in menu'; }
    item.click();

    const confirm = await N.dialogButton(isConfirm, 4000);
    if (confirm) confirm.click();

    const newToast = () => { const t = N.errorToast(); return t && t !== oldToast ? t : null; };
    const removed = () => N.menuButtons().length < before || !N.names().includes(name);

    const gone = await N.waitFor(() => newToast() || removed(), 12000);
    if (!gone) return 'notebook still listed after 12s';
    if (typeof gone === 'string') return 'page said: ' + gone;

    await N.sleep(500);                       // let the list settle, then re-check
    if (!removed()) return 'notebook reappeared after delete';
    return null;
  }

  job.total = await N.loadAll();

  for (let i = 0; i < LIMIT && !job.stopRequested; i++) {
    let rows = N.rows().filter((r) => !skip(r.name));
    if (!rows.length) {
      await N.loadAll();
      rows = N.rows().filter((r) => !skip(r.name));
      if (!rows.length) break;
      job.total = job.deleted.length + rows.length;
    }

    const row = rows[0];
    job.current = row.name;
    const err = await deleteOne(row);

    if (!err) {
      job.deleted.push(row.name);
      delay = BASE_DELAY;
    } else {
      const n = (tries.get(row.name) || 0) + 1;
      tries.set(row.name, n);
      if (n >= MAX_TRIES) job.failed.push(row.name + ' — ' + err);
      delay = Math.min(delay * 2, 8000);   // back off; likely re-render or rate limit
      N.closeOverlays();
    }
    await N.sleep(delay);
  }
  job.current = '';
});
