/* Popup framework. Features register themselves with App.register(); the page
 * side (page/*.js) is injected once into the NotebookLM tab and exposes
 * window.NLM. Everything talks to the page through App.call(). */

const App = (() => {
  const PAGE_FILES = ['page/core.js', 'page/actions/delete.js'];
  const URL_RE = /^https:\/\/notebook(lm)?\.google\.com\//;

  const $ = (sel, root = document) => root.querySelector(sel);
  const el = (tag, attrs = {}, text) => {
    const n = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => (k === 'class' ? (n.className = v) : n.setAttribute(k, v)));
    if (text != null) n.textContent = text;
    return n;
  };
  const log = (m) => { $('#log').textContent = m; };

  const features = [];
  let injectedTab = null;

  async function tab() {
    const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!t || !URL_RE.test(t.url || '')) {
      throw new Error('Open your Gemini Notebook / NotebookLM list page in this tab first.');
    }
    return t;
  }

  async function inject() {
    const t = await tab();
    if (injectedTab === t.id) return t;
    await chrome.scripting.executeScript({ target: { tabId: t.id }, files: PAGE_FILES });
    injectedTab = t.id;
    return t;
  }

  /* Run a function in the page. It must be self-contained (it is serialized). */
  async function call(func, args = []) {
    const t = await inject();
    try {
      const [res] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func, args });
      return res.result;
    } catch (e) {
      // Page was reloaded and lost window.NLM: inject again and retry once.
      if (!/NLM/.test(String(e))) throw e;
      injectedTab = null;
      const t2 = await inject();
      const [res] = await chrome.scripting.executeScript({ target: { tabId: t2.id }, func, args });
      return res.result;
    }
  }

  /* Convenience wrappers around window.NLM (see page/core.js). */
  const page = {
    scan: () => call(() => window.NLM.scan()),
    start: (action, opts = {}) => call((a, o) => window.NLM.start(a, o), [action, opts]),
    status: () => call(() => window.NLM.status()),
    stop: () => call(() => window.NLM.stop()),
  };

  /* Poll job status until done. onTick(status) is called every interval. */
  function poll(onTick, ms = 1000) {
    const id = setInterval(async () => {
      try {
        const s = await page.status();
        onTick(s);
        if (!s || s.done) clearInterval(id);
      } catch (e) { clearInterval(id); log(e.message); }
    }, ms);
    return () => clearInterval(id);
  }

  function register(feature) { features.push(feature); }

  function show(feature) {
    [...$('#nav').children].forEach((b) => b.classList.toggle('active', b.dataset.id === feature.id));
    const view = $('#view');
    view.innerHTML = '';
    log('');
    feature.render(view, api);
  }

  function boot() {
    const nav = $('#nav');
    if (features.length > 1) {
      features.forEach((f) => {
        const b = el('button', { 'data-id': f.id }, f.title);
        b.onclick = () => show(f);
        nav.appendChild(b);
      });
    }
    if (features[0]) show(features[0]);
  }

  const api = { $, el, log, page, poll };
  document.addEventListener('DOMContentLoaded', boot);
  return { register, ...api };
})();
