/* Feature: bulk delete every notebook on the list page. */
App.register({
  id: 'delete',
  title: 'Bulk delete',

  render(root, { el, log, page, poll }) {
    const scanBtn = el('button', {}, 'Scan notebooks');
    const runBtn = el('button', { class: 'danger', disabled: '' }, 'Delete all');
    const stopBtn = el('button', { disabled: '' }, 'Stop');
    const list = el('div', { class: 'list', hidden: '' });
    const confirm = el('div', { hidden: '' });
    const phrase = el('input', { placeholder: 'DELETE', autocomplete: 'off' });

    confirm.append(
      el('div', { class: 'warn' }, 'This permanently deletes these notebooks. It cannot be undone.'),
      el('p', { style: 'margin:8px 0 4px' }, 'Type DELETE to enable the button:'),
      phrase,
    );
    const row = el('div', { class: 'row' });
    row.append(scanBtn, runBtn, stopBtn);
    root.append(row, list, confirm);

    const report = (s) => {
      let m = 'Deleted ' + s.deleted.length + ' / ' + s.total;
      if (s.current) m += '\nWorking on: ' + s.current;
      if (s.failed.length) m += '\nSkipped (' + s.failed.length + '):\n' + s.failed.join('\n');
      m += s.done ? '\nFinished.' : '\n…keep the tab open.';
      log(m);
    };

    scanBtn.onclick = async () => {
      try {
        log('Scanning… (scrolling the page to load every notebook)');
        const names = await page.scan();
        list.hidden = false;
        list.innerHTML = '';
        names.forEach((n, i) => list.appendChild(el('div', {}, (i + 1) + '. ' + n)));
        if (!names.length) {
          list.textContent = 'No notebooks found. Make sure you are on the notebook list, not inside a notebook.';
          confirm.hidden = true;
          runBtn.disabled = true;
          return;
        }
        log('Found ' + names.length + ' notebook(s).');
        confirm.hidden = false;
        phrase.value = '';
        runBtn.disabled = true;
      } catch (e) { log(e.message); }
    };

    phrase.oninput = () => { runBtn.disabled = phrase.value.trim() !== 'DELETE'; };

    runBtn.onclick = async () => {
      try {
        runBtn.disabled = true;
        scanBtn.disabled = true;
        stopBtn.disabled = false;
        const r = await page.start('delete');
        if (r !== 'started') throw new Error('Could not start: ' + r);
        log('Working… keep this tab open. Closing the popup does not stop it.');
        poll((s) => {
          report(s);
          if (s.done) { scanBtn.disabled = false; stopBtn.disabled = true; }
        });
      } catch (e) { log(e.message); scanBtn.disabled = false; stopBtn.disabled = true; }
    };

    stopBtn.onclick = async () => {
      try { await page.stop(); log('Stopping after the current notebook…'); } catch (e) { log(e.message); }
    };

    // If a job is already running in the tab (popup was reopened), resume reporting.
    page.status().then((s) => {
      if (s && !s.done && s.started) {
        scanBtn.disabled = true; stopBtn.disabled = false;
        poll((st) => { report(st); if (st.done) { scanBtn.disabled = false; stopBtn.disabled = true; } });
      }
    }).catch(() => {});
  },
});
