const $ = (id) => document.getElementById(id);
const log = (m) => { $('log').textContent = m; };

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https:\/\/notebook(lm)?\.google\.com\//.test(tab.url || '')) {
    throw new Error('Open your Gemini Notebook / NotebookLM list page in this tab first.');
  }
  return tab;
}

async function run(func, args = []) {
  const tab = await activeTab();
  const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args });
  return res.result;
}

/* ---------- injected: runs in the page ---------- */

function pageScan() {
  const sel = 'button[aria-label="Project actions menu"]';
  const btns = [...document.querySelectorAll(sel)];
  return btns.map((b) => {
    const row = b.closest('tr') || b.closest('project-button') || b.parentElement;
    const cell = row && (row.querySelector('td') || row);
    return (cell ? cell.textContent : '').trim().replace(/\s+/g, ' ').slice(0, 90) || '(untitled)';
  });
}

function pageDeleteAll() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (el) => (el.textContent || '').trim().replace(/\s+/g, ' ').toLowerCase();

  async function waitFor(fn, ms = 6000) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      const v = fn();
      if (v) return v;
      await sleep(120);
    }
    return null;
  }

  const menuBtns = () => [...document.querySelectorAll('button[aria-label="Project actions menu"]')];

  window.__nbStop = false;
  window.__nbResult = { deleted: [], failed: [], done: false };

  (async () => {
    let guard = 0;
    while (menuBtns().length && guard++ < 500) {
      if (window.__nbStop) break;

      const btn = menuBtns()[0];
      const row = btn.closest('tr') || btn.closest('project-button');
      const name =
        ((row && (row.querySelector('td') || row).textContent) || '')
          .trim().replace(/\s+/g, ' ').slice(0, 90) || '(untitled)';
      const before = menuBtns().length;

      btn.click();

      const item = await waitFor(() => {
        const items = [...document.querySelectorAll(
          '.mat-mdc-menu-panel [role="menuitem"], .mat-mdc-menu-panel button')];
        return items.find((e) => /\bdelete\b/.test(norm(e)) && !/collection/.test(norm(e)));
      });
      if (!item) { window.__nbResult.failed.push(name + ' — menu item not found'); break; }
      item.click();

      // Confirmation dialog, if the UI shows one.
      const confirmBtn = await waitFor(() => {
        const dlg = document.querySelector('[role="dialog"], mat-dialog-container');
        if (!dlg) return null;
        return [...dlg.querySelectorAll('button')]
          .find((b) => /^(delete|delete notebook|yes, delete|confirm)$/.test(norm(b)));
      }, 3000);
      if (confirmBtn) confirmBtn.click();

      const gone = await waitFor(() => menuBtns().length < before, 10000);
      if (!gone) { window.__nbResult.failed.push(name + ' — row did not disappear'); break; }

      window.__nbResult.deleted.push(name);
      await sleep(700); // be gentle on the backend
    }
    window.__nbResult.done = true;
  })();

  return 'started';
}

function pageStatus() {
  return window.__nbResult || { deleted: [], failed: [], done: false };
}

function pageStop() { window.__nbStop = true; return true; }

/* ---------- popup wiring ---------- */

$('scan').onclick = async () => {
  try {
    const names = await run(pageScan);
    const box = $('list');
    box.style.display = 'block';
    box.innerHTML = '';
    names.forEach((n, i) => {
      const d = document.createElement('div');
      d.textContent = (i + 1) + '. ' + n;
      box.appendChild(d);
    });
    if (!names.length) {
      box.textContent = 'No notebooks found on this page. Make sure you are on the notebook list, not inside a notebook.';
      $('confirm').style.display = 'none';
      $('run').disabled = true;
      return;
    }
    log('Found ' + names.length + ' notebook(s).');
    $('confirm').style.display = 'block';
    $('phrase').value = '';
    $('run').disabled = true;
  } catch (e) { log(e.message); }
};

$('phrase').oninput = (e) => { $('run').disabled = e.target.value.trim() !== 'DELETE'; };

$('run').onclick = async () => {
  try {
    $('run').disabled = true;
    $('scan').disabled = true;
    await run(pageDeleteAll);
    log('Working… keep this tab open. Closing the popup does not stop it.');
    const poll = setInterval(async () => {
      try {
        const s = await run(pageStatus);
        log('Deleted ' + s.deleted.length +
            (s.failed.length ? '\nStopped on: ' + s.failed.join('\n') : '') +
            (s.done ? '\nFinished.' : '…'));
        if (s.done) { clearInterval(poll); $('scan').disabled = false; }
      } catch { clearInterval(poll); }
    }, 1200);
  } catch (e) { log(e.message); $('scan').disabled = false; }
};
