// MyHub Auto-Complete, content script v2.1
// Runs on MyHub pages and talks to the popup through chrome.storage.
// Guarded so the popup can inject it again into a tab that was open before the extension loaded.

(function () {
  if (window.__myhubAutoComplete) return;
  window.__myhubAutoComplete = true;

  const CONFIG = {
    dropdowns: ['Asia-Pacific', 'ASEAN', 'Singapore', 'Consulting', 'Risk Consulting'],
    purpose: 'Work Collaboration',
    contentTypes: ['EY Business Data/Information', 'Client Data/Information', 'Client Owned Records'],
    classification: 'EY Confidential C3',
    todos: '/v2/todos',
  };

  /* ================= storage (survives an extension reload without throwing) ================= */

  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };
  const get = (keys) => new Promise((res) => { try { chrome.storage.local.get(keys, (d) => res(d || {})); } catch (e) { res({}); } });
  const set = (obj) => new Promise((res) => { try { chrome.storage.local.set(obj, () => res()); } catch (e) { res(); } });

  // Log writes are serialised so quick successive lines are not lost. Every write bumps the heartbeat.
  let queue = Promise.resolve();
  function log(msg, cls) {
    console.log('[MyHub Auto] ' + msg);
    queue = queue.then(async () => {
      const logs = ((await get(['logs'])).logs || []).concat({ msg, cls: cls || '', ts: Date.now() }).slice(-150);
      await set({ logs, heartbeat: Date.now() });
    });
    return queue;
  }
  let lastPhase = '';
  const phase = (text) => { lastPhase = text; return set({ phase: text, heartbeat: Date.now() }); };
  const getConfig = async () => { const d = await get(['running', 'dryRun']); return { running: alive() && !!d.running, dryRun: !!d.dryRun }; };
  const isRunning = async () => (await getConfig()).running;

  /* ================= page helpers ================= */

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const cleanText = (t) => (t || '')
    .replace(/[▶▷◀◁➕➖⭐⚠✔✖⏱⏰]|\uD83D[\uDC00-\uDFFF]|️|​| /g, '')
    .replace(/[^\x20-\x7E\xA0-\xFF]/g, '').replace(/\s+/g, ' ').trim();
  const visible = (el) => !!el && el.offsetParent !== null;
  const buttons = () => [...document.querySelectorAll('button')].filter(visible);
  const findButton = (text) => buttons().find((b) => b.innerText.includes(text)) || null;
  const pageHas = (text) => document.body.innerText.includes(text);
  const snapshot = () => document.body.innerText;
  const startButtons = () => buttons().filter((b) => b.innerText.includes('Start task'));

  function clickButton(text) {
    const b = findButton(text);
    if (!b) return false;
    b.scrollIntoView({ block: 'center' });
    b.click();
    return true;
  }

  // What is on screen, for the log when a step does not look as expected.
  const buttonTexts = () => [...new Set(buttons().map((b) => cleanText(b.innerText)).filter(Boolean))].slice(0, 10).join(' | ') || 'none';
  function headline() {
    const h = [...document.querySelectorAll('h1, h2, h3, [role="heading"]')].find(visible);
    return cleanText(h ? h.innerText : document.body.innerText.slice(0, 100)).slice(0, 80);
  }
  const where = () => 'Page "' + headline() + '", buttons: ' + buttonTexts();

  function taskInfo(btn) {
    let el = btn.parentElement;
    for (let i = 0; i < 10 && el; i++) {
      const lines = (el.innerText || '').split('\n').map(cleanText)
        .filter((l) => l && l !== 'Start task' && !l.startsWith('Due on') && l !== '...');
      if (lines.length) return { name: lines[0], type: lines[1] || '' };
      el = el.parentElement;
    }
    return { name: 'Unknown', type: '' };
  }

  const secondaryOwnerOk = () =>
    !pageHas('Add the Secondary Workspace Owner to proceed') && !pageHas('Add Secondary Workspace Owner');

  async function gotoTodos() {
    if (!location.hash.includes('todos')) { location.hash = CONFIG.todos; await sleep(3000); }
  }

  // Poll pred() once a second until it returns something, reporting the wait as the current phase.
  // Returns pred()'s value, null on timeout, 'stopped' when the user pressed Stop.
  async function waitFor(pred, ms, label) {
    const t0 = Date.now();
    for (;;) {
      if (!(await isRunning())) return 'stopped';
      const r = pred();
      if (r) return r;
      if (Date.now() - t0 >= ms) return null;
      await phase(label + ' (' + Math.round((Date.now() - t0) / 1000) + 's)');
      await sleep(1000);
    }
  }

  /* ================= Business Context form ================= */

  async function fillCombo(index, value) {
    const inputs = document.querySelectorAll('input[role="combobox"]');
    if (index >= inputs.length) return false;
    const inp = inputs[index];
    if (inp.value === value) return true;
    const arrow = (inp.closest('.ms-ComboBox') || inp.parentElement)?.querySelector('button');
    if (!arrow) return false;
    for (let attempt = 0; attempt < 3; attempt++) {
      arrow.click();
      await sleep(1500);
      const opt = [...document.querySelectorAll('[role="option"]')].find((o) => o.innerText.trim() === value);
      if (opt) { opt.click(); await sleep(2000); return true; }
      document.body.click();
      await sleep(1000);
    }
    return false;
  }

  function pick(sel, match) {
    for (const input of document.querySelectorAll(sel)) {
      if (match(input)) {
        if (!input.checked) { input.click(); input.dispatchEvent(new Event('change', { bubbles: true })); }
        return true;
      }
    }
    return false;
  }
  const clickRadio = (label) => pick('input[type="radio"]', (r) => (r.parentElement?.innerText?.trim() || '').startsWith(label));
  const clickCheckbox = (label) => pick('input[type="checkbox"]', (c) =>
    (c.name || '').includes(label) || (c.parentElement?.innerText?.trim() || '').startsWith(label));

  async function fillBusinessContext() {
    for (let i = 0; i < CONFIG.dropdowns.length; i++) {
      await phase('Business Context: dropdown ' + (i + 1) + ' of ' + CONFIG.dropdowns.length);
      let found = false;
      for (let w = 0; w < 10; w++) {
        if (document.querySelectorAll('input[role="combobox"]').length > i) { found = true; break; }
        await sleep(1500);
      }
      if (!found) { log('    Dropdown ' + (i + 1) + ': did not appear. Skipping rest.', 'warn'); break; }
      const ok = await fillCombo(i, CONFIG.dropdowns[i]);
      log('    Dropdown ' + (i + 1) + ': ' + CONFIG.dropdowns[i] + (ok ? '' : ' (FAILED)'), ok ? 'ok' : 'warn');
      await sleep(2500);
    }
    await sleep(1000);
    const p = clickRadio(CONFIG.purpose); log('    Purpose: ' + CONFIG.purpose + (p ? '' : ' (not found)'), p ? 'ok' : 'warn'); await sleep(500);
    for (const ct of CONFIG.contentTypes) { const c = clickCheckbox(ct); log('    Content: ' + ct + (c ? '' : ' (not found)'), c ? 'ok' : 'warn'); await sleep(300); }
    const k = clickRadio(CONFIG.classification); log('    Classification: ' + CONFIG.classification + (k ? '' : ' (not found)'), k ? 'ok' : 'warn');
    await sleep(2000);
  }

  /* ================= one task ================= */

  function stepLabel(step) {
    if (pageHas('Workspace Owners') && (pageHas('Confirm or change') || pageHas('governance tasks'))) return 'Workspace Owners';
    if (pageHas('Membership renewal') || (pageHas('Membership') && pageHas('M365'))) return 'Membership';
    if (pageHas('users with direct access')) return 'SharePoint (users)';
    if (pageHas('SharePoint permissions') && pageHas('groups')) return 'SharePoint (groups)';
    if (pageHas('Site admin')) return 'Site admin';
    if (pageHas('Sharing Links')) return 'Sharing Links';
    if (pageHas('Business Context')) return 'Business Context';
    return 'Step ' + (step + 1);
  }

  const hasIntake = () => pageHas('Do you still need this team') || pageHas('Are you responsible for this team') || pageHas('Required intake question');
  const wizardButton = () => (findButton('Submit') ? 'submit' : findButton('Continue') ? 'continue' : null);

  // true = completed, false = skipped, null = stopped
  async function processTask(name, dryRun) {
    log('Processing: ' + name, 'info');

    let yes = 0;
    for (let i = 0; i < 3; i++) {
      const got = await waitFor(() => (hasIntake() && findButton('Yes') ? 'intake' : wizardButton()), i ? 5000 : 12000, 'Waiting for the task to open');
      if (got === 'stopped') return null;
      if (got !== 'intake') break;
      clickButton('Yes'); yes++;
      log('  Clicked Yes (question ' + yes + ')', 'ok');
      await sleep(1500);
    }
    if (!yes) { log('  No intake question found, skipping. ' + where(), 'warn'); return false; }

    let stuck = 0;
    for (let step = 0; step < 15; step++) {
      const got = await waitFor(wizardButton, 15000, 'Waiting for wizard step ' + (step + 1));
      if (got === 'stopped') return null;
      if (!got) { log('  Step ' + (step + 1) + ': no Submit or Continue after 15s. ' + where(), 'fail'); return false; }

      if (got === 'submit') {
        if (pageHas('Business Context')) {
          log('  Filling Business Context...', 'info');
          await fillBusinessContext();
          log('  Business Context filled.', 'ok');
          await sleep(1000);
        }
        if (dryRun) { log('  [DRY RUN] Would click Submit. Clicking Cancel.', 'warn'); clickButton('Cancel'); return true; }
        const before = snapshot();
        await phase('Submitting');
        clickButton('Submit');
        const moved = await waitFor(() => (snapshot() !== before ? 'changed' : null), 10000, 'Waiting for the submit to go through');
        if (moved === 'stopped') return null;
        if (!moved) { log('  Submit did not go through. ' + where(), 'fail'); clickButton('Cancel'); return false; }
        log('  Submitted.', 'ok');
        return true;
      }

      if (pageHas('Workspace Owners') && pageHas('Primary Workspace Owner') && !secondaryOwnerOk()) {
        log('  Secondary owner missing, skipping task.', 'warn');
        clickButton('Cancel');
        return false;
      }
      const label = stepLabel(step);
      const before = snapshot();
      clickButton('Continue');
      log('  ' + label + ' -> Continue', 'ok');
      const moved = await waitFor(() => (snapshot() !== before ? 'changed' : null), 8000, 'Waiting for the next step');
      if (moved === 'stopped') return null;
      if (moved) { stuck = 0; continue; }
      if (++stuck >= 2) { log('  Page did not change after Continue twice. ' + where(), 'fail'); clickButton('Cancel'); return false; }
      log('  Page did not change after Continue, trying again.', 'warn');
    }
    log('  Exceeded max steps.', 'fail');
    return false;
  }

  /* ================= main loop ================= */

  let loopActive = false;

  async function runAutomation() {
    if (loopActive || !(await isRunning())) return;
    loopActive = true;
    const hb = setInterval(() => set({ heartbeat: Date.now() }), 3000);
    const { dryRun } = await getConfig();
    let completed = 0, skipped = 0, total = 0, failed = '';
    const skippedNames = [];
    const attempted = new Set();

    try {
      log('=== MyHub Auto-Complete ===' + (dryRun ? ' (DRY RUN)' : ''), 'info');
      await phase('Opening the task list');
      await gotoTodos();
      const first = await waitFor(() => (startButtons().length ? 'ok' : null), 30000, 'Loading the task list');
      if (first === 'stopped') { log('Stopped by user.', 'warn'); return; }
      if (!first) { log('No "Start task" button after 30s. ' + where(), 'warn'); return; }

      total = startButtons().length;
      const names = startButtons().slice(0, 3).map((b) => taskInfo(b).name).join(', ');
      log('Found ' + total + ' task(s): ' + names + (total > 3 ? ', ...' : ''), 'info');
      await set({ completed: 0, skipped: 0, skippedNames: [], total });

      let n = 0;
      while (await isRunning()) {
        await gotoTodos();
        const ready = await waitFor(() => (startButtons().length ? 'ok' : null), 15000, 'Loading the task list');
        if (ready === 'stopped') break;
        if (!ready) { log('All tasks processed.', 'ok'); break; }

        let target = null, info = null;
        for (const b of startButtons()) {
          const t = taskInfo(b);
          const key = t.name + '|' + t.type;
          if (!attempted.has(key)) { attempted.add(key); target = b; info = t; break; }
        }
        if (!target) { log('All visible tasks have been attempted.', 'info'); break; }

        n++;
        log('--- Task ' + n + ' of ' + total + ': ' + info.name + ' (' + info.type + ') ---', 'info');
        await phase('Opening task ' + n + ': ' + info.name);
        target.scrollIntoView({ block: 'center' });
        target.click();
        await sleep(2000);

        let result;
        try { result = await processTask(info.name, dryRun); }
        catch (e) { log('  Error: ' + e.message, 'fail'); result = false; }
        if (result === null) { log('Stopped by user.', 'warn'); break; }
        if (result) { completed++; log('  Task ' + n + ': COMPLETED', 'ok'); }
        else { skipped++; skippedNames.push(info.name); log('  Task ' + n + ': SKIPPED', 'warn'); }
        await set({ completed, skipped, skippedNames });

        await phase('Returning to the task list');
        await sleep(1500);
        location.hash = CONFIG.todos;
        await sleep(2500);
      }

      log('=== SUMMARY === Completed ' + completed + ' of ' + total + (skipped ? ', skipped ' + skipped : ''), completed ? 'ok' : 'warn');
      skippedNames.forEach((s) => log('  - ' + s, 'warn'));
    } catch (e) {
      failed = String((e && e.message) || e);
      log('Stopped with an error: ' + failed, 'fail');
    } finally {
      clearInterval(hb);
      await queue;
      await set({ status: failed ? 'error' : 'done', error: failed, running: false, completed, skipped, skippedNames, total, phase: 'Finished', heartbeat: Date.now() });
      loopActive = false;
    }
  }

  /* ================= wiring ================= */

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg && msg.type === 'ping') reply({ alive: true, running: loopActive, phase: lastPhase });
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.running && changes.running.newValue === true) runAutomation();
  });

  getConfig().then((cfg) => { if (cfg.running) setTimeout(runAutomation, 2000); });   // resume after a reload
})();
