// ═══════════════════════════════════════════════════════════════════════════
// MyHub Auto-Complete — Content Script v3
// Runs directly on MyHub pages. Communicates with popup via chrome.storage.
// ═══════════════════════════════════════════════════════════════════════════

(function () {
  if (window.__myhubAutoComplete) return;
  window.__myhubAutoComplete = true;

  // ── Logging ───────────────────────────────────────────────────────────
  function addLog(msg, cls) {
    chrome.storage.local.get(['logs'], (data) => {
      const logs = data.logs || [];
      logs.push({ msg, cls, ts: Date.now() });
      if (logs.length > 100) logs.splice(0, logs.length - 100);
      chrome.storage.local.set({ logs });
    });
    console.log(`[MyHub Auto] ${msg}`);
  }

  function setStatus(status, completed, skipped, skippedNames, total) {
    chrome.storage.local.set({
      status,
      completed: completed || 0,
      skipped: skipped || 0,
      skippedNames: skippedNames || [],
      total: total || 0,
    });
  }

  // ── DOM helpers ───────────────────────────────────────────────────────
  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function cleanText(text) {
    // Remove icon characters and extra whitespace
    return text.replace(/[\u25B6\u25B7\u25C0\u25C1\u2795\u2796\u2B50\u26A0\u2714\u2716\u23F1\u23F0\uD83D[\uDC00-\uDFFF]|\uFE0F|\u200B|\u00A0]/g, '')
               .replace(/[^\x20-\x7E\xA0-\xFF]/g, '')
               .replace(/\s+/g, ' ')
               .trim();
  }

  function findButtonByText(text) {
    const buttons = document.querySelectorAll('button');
    for (const btn of buttons) {
      if (btn.innerText.includes(text) && btn.offsetParent !== null) {
        return btn;
      }
    }
    return null;
  }

  function clickButton(text) {
    const btn = findButtonByText(text);
    if (btn) {
      btn.scrollIntoView({ block: 'center' });
      btn.click();
      return true;
    }
    return false;
  }

  function pageContains(text) {
    return document.body.innerText.includes(text);
  }

  function getVisibleStartTaskButtons() {
    const buttons = document.querySelectorAll('button');
    const result = [];
    for (const btn of buttons) {
      if (btn.innerText.includes('Start task') && btn.offsetParent !== null) {
        result.push(btn);
      }
    }
    return result;
  }

  function getTaskNameForButton(btn) {
    let el = btn.parentElement;
    for (let i = 0; i < 10 && el; i++) {
      const text = el.innerText || '';
      const lines = text
        .split('\n')
        .map((l) => cleanText(l))
        .filter((l) => l && l !== 'Start task' && !l.startsWith('Due on') && l !== '...' && l !== '');
      if (lines.length >= 1) {
        return { name: lines[0], type: lines[1] || '' };
      }
      el = el.parentElement;
    }
    return { name: 'Unknown', type: '' };
  }

  function checkSecondaryOwnerExists() {
    return (
      !pageContains('Add the Secondary Workspace Owner to proceed') &&
      !pageContains('Add Secondary Workspace Owner')
    );
  }

  // ── Config / state ────────────────────────────────────────────────────
  function getConfig() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['running', 'dryRun'], (data) => {
        resolve({ running: !!data.running, dryRun: !!data.dryRun });
      });
    });
  }

  function getState() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['completed', 'skipped', 'skippedNames', 'total'], (data) => {
        resolve({
          completed: data.completed || 0,
          skipped: data.skipped || 0,
          skippedNames: data.skippedNames || [],
          total: data.total || 0,
        });
      });
    });
  }

  // ── Business Context form filling ─────────────────────────────────────
  const BUSINESS_CONTEXT = {
    dropdowns: [
      'Asia-Pacific',       // 0: Which Area
      'ASEAN',              // 1: Which Region
      'Singapore',          // 2: Which Member Firm
      'Consulting',         // 3: Service Line
      'Risk Consulting',    // 4: Sub-Service Line
    ],
    purpose: 'Work Collaboration',
    contentTypes: [
      'EY Business Data/Information',
      'Client Data/Information',
      'Client Owned Records',
    ],
    classification: 'EY Confidential C3',
  };

  async function fillComboBox(index, value) {
    const inputs = document.querySelectorAll('input[role="combobox"]');
    if (index >= inputs.length) {
      return false;
    }

    const inp = inputs[index];
    if (inp.value === value) return true;

    const parent = inp.closest('.ms-ComboBox') || inp.parentElement;
    const arrowBtn = parent?.querySelector('button');
    if (!arrowBtn) return false;

    // Try up to 3 times
    for (let attempt = 0; attempt < 3; attempt++) {
      arrowBtn.click();
      await sleep(1500);

      const opts = document.querySelectorAll('[role="option"]');
      let clicked = false;
      for (const o of opts) {
        if (o.innerText === value || o.innerText.trim() === value) {
          o.click();
          clicked = true;
          break;
        }
      }

      if (clicked) {
        await sleep(2000);
        return true;
      }

      document.body.click();
      await sleep(1000);
    }

    return false;
  }

  function clickRadioByLabel(labelText) {
    const radios = document.querySelectorAll('input[type="radio"]');
    for (const radio of radios) {
      const parentText = radio.parentElement?.innerText?.trim() || '';
      if (parentText.startsWith(labelText)) {
        if (!radio.checked) {
          radio.click();
          radio.dispatchEvent(new Event('change', { bubbles: true }));
        }
        return true;
      }
    }
    return false;
  }

  function clickCheckboxByLabel(labelText) {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (const cb of checkboxes) {
      const cbName = cb.name || '';
      const parentText = cb.parentElement?.innerText?.trim() || '';
      if (cbName.includes(labelText) || parentText.startsWith(labelText)) {
        if (!cb.checked) {
          cb.click();
          cb.dispatchEvent(new Event('change', { bubbles: true }));
        }
        return true;
      }
    }
    return false;
  }

  async function fillBusinessContext() {
    for (let i = 0; i < BUSINESS_CONTEXT.dropdowns.length; i++) {
      const value = BUSINESS_CONTEXT.dropdowns[i];

      // Wait for this dropdown to exist (cascading load)
      let found = false;
      for (let wait = 0; wait < 10; wait++) {
        const inputs = document.querySelectorAll('input[role="combobox"]');
        if (inputs.length > i) { found = true; break; }
        await sleep(1500);
      }

      if (!found) {
        addLog(`    Dropdown ${i + 1}: Did not appear. Skipping rest.`, 'warn');
        break;
      }

      const success = await fillComboBox(i, value);
      addLog(`    Dropdown ${i + 1}: ${value}${success ? '' : ' (FAILED)'}`, success ? 'ok' : 'warn');
      await sleep(2500);
    }

    await sleep(1000);

    clickRadioByLabel(BUSINESS_CONTEXT.purpose);
    addLog(`    Purpose: ${BUSINESS_CONTEXT.purpose}`, 'ok');
    await sleep(500);

    for (const ct of BUSINESS_CONTEXT.contentTypes) {
      clickCheckboxByLabel(ct);
      addLog(`    Content: ${ct}`, 'ok');
      await sleep(300);
    }

    clickRadioByLabel(BUSINESS_CONTEXT.classification);
    addLog(`    Classification: ${BUSINESS_CONTEXT.classification}`, 'ok');
    await sleep(2000);
  }

  // ── Process a single task wizard ──────────────────────────────────────
  async function processTask(taskName, dryRun) {
    addLog(`Processing: ${taskName}`, 'info');

    // Phase 1: Click Yes for intake questions (fast — 1.5s wait)
    let yesCount = 0;
    for (let i = 0; i < 3; i++) {
      await sleep(1500);

      const config = await getConfig();
      if (!config.running) { addLog('Stopped by user.', 'warn'); return null; }

      const hasIntake =
        pageContains('Do you still need this team') ||
        pageContains('Are you responsible for this team') ||
        pageContains('Required intake question');

      if (hasIntake && findButtonByText('Yes')) {
        clickButton('Yes');
        addLog(`  Clicked Yes (question ${yesCount + 1})`, 'ok');
        yesCount++;
        await sleep(1500);
      } else {
        break;
      }
    }

    if (yesCount === 0) {
      addLog(`  No intake question found. Skipping.`, 'warn');
      return false;
    }

    // Phase 2: Walk through wizard steps
    for (let step = 0; step < 15; step++) {
      // Fast wait for simple review pages, longer for Business Context
      await sleep(1200);

      const config = await getConfig();
      if (!config.running) { addLog('Stopped by user.', 'warn'); return null; }

      // Check for Submit (final step — Business Context page)
      if (findButtonByText('Submit')) {
        if (pageContains('Business Context')) {
          addLog(`  Filling Business Context...`, 'info');
          await fillBusinessContext();
          addLog(`  Business Context filled.`, 'ok');
          await sleep(1000);
        }

        if (dryRun) {
          addLog(`  [DRY RUN] Would click Submit. Clicking Cancel.`, 'warn');
          clickButton('Cancel');
          return true;
        } else {
          clickButton('Submit');
          addLog(`  Submitted!`, 'ok');
          return true;
        }
      }

      // Check for Continue
      if (findButtonByText('Continue')) {
        if (pageContains('Workspace Owners') && pageContains('Primary Workspace Owner')) {
          if (!checkSecondaryOwnerExists()) {
            addLog(`  Secondary owner missing. Skipping task.`, 'warn');
            clickButton('Cancel');
            return false;
          }
        }

        // Page label for logging
        let label = 'Step ' + (step + 1);
        if (pageContains('Workspace Owners') && (pageContains('Confirm or change') || pageContains('governance tasks')))
          label = 'Workspace Owners';
        else if (pageContains('Membership renewal') || (pageContains('Membership') && pageContains('M365')))
          label = 'Membership';
        else if (pageContains('users with direct access')) label = 'SharePoint (users)';
        else if (pageContains('SharePoint permissions') && pageContains('groups')) label = 'SharePoint (groups)';
        else if (pageContains('Site admin')) label = 'Site admin';
        else if (pageContains('Sharing Links')) label = 'Sharing Links';
        else if (pageContains('Business Context')) label = 'Business Context';

        clickButton('Continue');
        addLog(`  ${label} -> Continue`, 'ok');
        continue;
      }

      // Neither found — don't retry, just fail this task
      addLog(`  Step ${step + 1}: No Submit or Continue found.`, 'fail');
      return false;
    }

    addLog(`  Exceeded max steps.`, 'fail');
    return false;
  }

  // ── Main automation loop ──────────────────────────────────────────────
  async function runAutomation() {
    const config = await getConfig();
    if (!config.running) return;

    const dryRun = config.dryRun;
    let completed = 0;
    let skipped = 0;
    let skippedNames = [];

    addLog('=== MyHub Auto-Complete ===' + (dryRun ? ' (DRY RUN)' : ''), 'info');

    // Ensure we're on the todos page
    if (!window.location.hash.includes('todos')) {
      window.location.hash = '/v2/todos';
      await sleep(4000);
    }

    // Wait for tasks to load
    addLog('Loading task list...', 'info');
    let foundTasks = false;
    for (let i = 0; i < 15; i++) {
      await sleep(2000);
      if (getVisibleStartTaskButtons().length > 0) { foundTasks = true; break; }
    }

    if (!foundTasks) {
      addLog('No tasks found. Nothing to do!', 'warn');
      setStatus('done', 0, 0, [], 0);
      chrome.storage.local.set({ running: false });
      return;
    }

    const totalTasks = getVisibleStartTaskButtons().length;
    addLog(`Found ${totalTasks} task(s). Starting...\n`, 'info');
    setStatus('running', 0, 0, [], totalTasks);

    // Track task names we've already attempted (to avoid infinite loops)
    const attemptedTasks = new Set();
    let taskNumber = 0;

    while (true) {
      const cfg = await getConfig();
      if (!cfg.running) { addLog('Stopped by user.', 'warn'); break; }

      // Navigate to todos if needed
      if (!window.location.hash.includes('todos')) {
        window.location.hash = '/v2/todos';
        await sleep(4000);
      }

      // Wait for Start task buttons
      let buttons = [];
      for (let i = 0; i < 10; i++) {
        await sleep(1500);
        buttons = getVisibleStartTaskButtons();
        if (buttons.length > 0) break;
      }

      if (buttons.length === 0) {
        addLog('\nAll tasks processed!', 'ok');
        break;
      }

      // Find the first task we haven't attempted yet
      let targetBtn = null;
      let taskInfo = null;

      for (const btn of buttons) {
        const info = getTaskNameForButton(btn);
        const taskKey = `${info.name}|${info.type}`;
        if (!attemptedTasks.has(taskKey)) {
          targetBtn = btn;
          taskInfo = info;
          attemptedTasks.add(taskKey);
          break;
        }
      }

      if (!targetBtn) {
        // All visible tasks have been attempted — we're done
        addLog('\nAll tasks have been attempted.', 'info');
        break;
      }

      taskNumber++;
      addLog(`--- Task ${taskNumber} of ${totalTasks}: ${taskInfo.name} (${taskInfo.type}) ---`, 'info');
      targetBtn.scrollIntoView({ block: 'center' });
      targetBtn.click();
      await sleep(2500);

      // Process the wizard — NO retries on failure
      try {
        const result = await processTask(taskInfo.name, dryRun);
        if (result === null) {
          break; // Stopped by user
        } else if (result) {
          completed++;
          addLog(`  Task ${taskNumber}: COMPLETED\n`, 'ok');
        } else {
          skipped++;
          skippedNames.push(taskInfo.name);
          addLog(`  Task ${taskNumber}: SKIPPED\n`, 'warn');
        }
        setStatus('running', completed, skipped, skippedNames, totalTasks);
      } catch (err) {
        addLog(`  Error: ${err.message}`, 'fail');
        skipped++;
        skippedNames.push(taskInfo.name);
        addLog(`  Task ${taskNumber}: FAILED\n`, 'fail');
        setStatus('running', completed, skipped, skippedNames, totalTasks);
      }

      await sleep(2000);

      // Navigate back to todos
      window.location.hash = '/v2/todos';
      await sleep(3000);
    }

    // Final summary
    addLog(`\n=== SUMMARY ===`, 'info');
    addLog(`Completed: ${completed} of ${totalTasks}`, completed > 0 ? 'ok' : 'warn');
    if (skipped > 0) {
      addLog(`Skipped: ${skipped}`, 'warn');
      skippedNames.forEach(n => addLog(`  - ${n}`, 'warn'));
    }
    addLog(`===============\n`, 'info');

    setStatus('done', completed, skipped, skippedNames, totalTasks);
    chrome.storage.local.set({ running: false });
  }

  // ── Listen for start signal ───────────────────────────────────────────
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.running && changes.running.newValue === true) {
      runAutomation();
    }
  });

  getConfig().then((cfg) => {
    if (cfg.running) {
      setTimeout(runAutomation, 2000);
    }
  });
})();
