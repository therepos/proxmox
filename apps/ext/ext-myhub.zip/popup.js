const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const statusBox = document.getElementById('statusBox');
const summaryDiv = document.getElementById('summary');
const dryRunCheck = document.getElementById('dryRun');
const optionsPanel = document.getElementById('optionsPanel');
const runningNote = document.getElementById('runningNote');

// ── Render logs from storage ──────────────────────────────────────────
function renderLogs(logs) {
  statusBox.innerHTML = '';
  if (!logs || logs.length === 0) return;
  statusBox.style.display = 'block';
  logs.forEach((l) => {
    const line = document.createElement('div');
    line.className = 'log-line ' + (l.cls || '');
    line.textContent = l.msg;
    statusBox.appendChild(line);
  });
  statusBox.scrollTop = statusBox.scrollHeight;
}

function updateUI(data) {
  const isRunning = !!data.running;
  const status = data.status || 'idle';

  startBtn.style.display = isRunning ? 'none' : 'block';
  startBtn.disabled = false;
  stopBtn.style.display = isRunning ? 'block' : 'none';
  optionsPanel.style.display = isRunning ? 'none' : 'block';
  runningNote.style.display = isRunning ? 'block' : 'none';

  if (isRunning) {
    statusBox.className = 'status-box running';
  } else if (status === 'done') {
    statusBox.className = 'status-box done';
  } else {
    statusBox.className = 'status-box';
  }

  renderLogs(data.logs || []);

  // Show summary if done
  if (status === 'done' && !isRunning) {
    const completed = data.completed || 0;
    const skipped = data.skipped || 0;
    const total = data.total || 0;
    const skippedNames = data.skippedNames || [];
    summaryDiv.style.display = 'block';
    let html = `<strong>Done!</strong> Completed: ${completed}/${total}`;
    if (skipped > 0) {
      html += `, Skipped: ${skipped}`;
      html += '<br>Skipped: ' + skippedNames.join(', ');
    }
    summaryDiv.innerHTML = html;
  } else if (isRunning) {
    const completed = data.completed || 0;
    const skipped = data.skipped || 0;
    const total = data.total || 0;
    if (total > 0) {
      summaryDiv.style.display = 'block';
      summaryDiv.innerHTML = `<strong>Progress:</strong> ${completed + skipped}/${total} (${completed} done, ${skipped} skipped)`;
    }
  } else {
    summaryDiv.style.display = 'none';
  }
}

// ── Load current state on popup open ──────────────────────────────────
chrome.storage.local.get(['running', 'dryRun', 'status', 'logs', 'completed', 'skipped', 'skippedNames'], (data) => {
  dryRunCheck.checked = !!data.dryRun;
  updateUI(data);
});

// ── Live updates while popup is open ──────────────────────────────────
chrome.storage.onChanged.addListener(() => {
  chrome.storage.local.get(['running', 'dryRun', 'status', 'logs', 'completed', 'skipped', 'skippedNames'], (data) => {
    updateUI(data);
  });
});

// ── Start button ──────────────────────────────────────────────────────
startBtn.addEventListener('click', () => {
  const dryRun = dryRunCheck.checked;
  // Clear previous state and start
  chrome.storage.local.set({
    running: true,
    dryRun,
    status: 'running',
    logs: [],
    completed: 0,
    skipped: 0,
    skippedNames: [],
  });
});

// ── Stop button ───────────────────────────────────────────────────────
stopBtn.addEventListener('click', () => {
  chrome.storage.local.set({ running: false });
});
